public class Constants {
	public static final String actionDrop = "drop";
	public static final String actionDuplicate = "duplicate";
	public static final String actionDelay = "delay";
	
	public static final String logicalClockService = "logical";
	public static final String vectorClockService = "vector";
	
	public static final String logSendKind = "logSend";
	public static final String logRecvKind = "logRecv";
}
